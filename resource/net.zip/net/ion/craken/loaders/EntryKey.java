package net.ion.craken.loaders;

public interface EntryKey {

	public static final String VALUE = "__value";

	public static final String ID = "__id";
	public static final String LASTMODIFIED = "__lastmodified";
	public static final String PROPS = "__props";

	public static final String PARENT = "__parent";

}
