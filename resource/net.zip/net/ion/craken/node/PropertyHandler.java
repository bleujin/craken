package net.ion.craken.node;

public interface PropertyHandler<T> {

}
