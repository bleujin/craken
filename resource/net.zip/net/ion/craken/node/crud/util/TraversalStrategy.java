package net.ion.craken.node.crud.util;


public enum TraversalStrategy {
	BreadthFirst, DepthFirst
}
