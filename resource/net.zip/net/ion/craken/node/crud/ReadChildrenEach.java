package net.ion.craken.node.crud;

public interface ReadChildrenEach<T> {

	public T handle(ReadChildrenIterator citer) ;
}
