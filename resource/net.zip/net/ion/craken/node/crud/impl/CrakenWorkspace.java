package net.ion.craken.node.crud.impl;

import java.io.IOException;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

import org.apache.lucene.analysis.Analyzer;
import org.infinispan.AdvancedCache;
import org.infinispan.Cache;
import org.infinispan.atomic.AtomicMap;
import org.infinispan.atomic.impl.AtomicHashMap;
import org.infinispan.context.Flag;
import org.infinispan.io.GridFilesystem;
import org.infinispan.notifications.cachelistener.event.CacheEntryModifiedEvent;
import org.infinispan.notifications.cachelistener.event.CacheEntryRemovedEvent;

import net.ion.craken.listener.CDDMListener;
import net.ion.craken.listener.WorkspaceListener;
import net.ion.craken.mr.NodeMapReduce;
import net.ion.craken.node.NodeWriter;
import net.ion.craken.node.ReadSession;
import net.ion.craken.node.Repository;
import net.ion.craken.node.TranExceptionHandler;
import net.ion.craken.node.TransactionJob;
import net.ion.craken.node.Workspace;
import net.ion.craken.node.WriteNode;
import net.ion.craken.node.WriteSession;
import net.ion.craken.node.crud.TreeNode;
import net.ion.craken.node.crud.TreeNodeKey;
import net.ion.craken.node.crud.WriteNodeImpl;
import net.ion.craken.node.crud.tree.TreeCache;
import net.ion.craken.node.crud.tree.TreeCacheFactory;
import net.ion.craken.node.crud.tree.impl.TreeCacheImpl;
import net.ion.craken.tree.Fqn;
import net.ion.craken.tree.PropertyId;
import net.ion.craken.tree.PropertyValue;
import net.ion.framework.mte.Engine;
import net.ion.nsearcher.config.Central;

public class CrakenWorkspace implements Workspace {

	private TreeCache<PropertyId, PropertyValue> icache;

	public CrakenWorkspace(AdvancedCache<PropertyId, PropertyValue> cache) {
		this.icache = new TreeCacheFactory().createTreeCache(cache);
	}

	@Override
	public void registered(Workspace workspace) {
		// TODO Auto-generated method stub

	}

	@Override
	public void unRegistered(Workspace workspace) {
		// TODO Auto-generated method stub

	}

	@Override
	public WriteNode createNode(WriteSession wsession, Set<Fqn> ancestorsFqn, Fqn fqn) {
		return WriteNodeImpl. icache.getNode(fqn);
	}

	@Override
	public WriteNode resetNode(WriteSession wsession, Set<Fqn> ancestorsFqn, Fqn fqn) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public WriteNode writeNode(WriteSession wsession, Set<Fqn> ancestorsFqn, Fqn fqn) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public TreeNode readNode(Fqn fqn) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public AtomicMap<PropertyId, PropertyValue> props(Fqn fqn) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public AtomicMap<String, Fqn> strus(Fqn fqn) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Workspace start() {
		
		return this;
	}

	@Override
	public void close() {
		// TODO Auto-generated method stub

	}

	@Override
	public <T> T getAttribute(String key, Class<T> clz) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String wsName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Workspace executorService(ExecutorService es) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Workspace withFlag(Flag... flags) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <T> Future<T> tran(WriteSession wsession, TransactionJob<T> tjob) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <T> Future<T> tran(WriteSession wsession, TransactionJob<T> tjob, TranExceptionHandler ehandler) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <T> Future<T> tran(ExecutorService exec, WriteSession wsession, TransactionJob<T> tjob, TranExceptionHandler ehandler) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Repository repository() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean exists(Fqn f) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Central central() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void continueUnit(WriteSession wsession) throws IOException {
		// TODO Auto-generated method stub

	}

	@Override
	public void begin() {
		// TODO Auto-generated method stub

	}

	@Override
	public void failEnd() {
		// TODO Auto-generated method stub

	}

	@Override
	public void end() {
		icache.stop();
	}

	@Override
	public Workspace addListener(WorkspaceListener listener) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void removeListener(WorkspaceListener listener) {
		// TODO Auto-generated method stub

	}

	@Override
	public ExecutorService executor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Engine parseEngine() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public <Ri, Rv> Future<Map<Ri, Rv>> mapReduce(NodeMapReduce<Ri, Rv> mapper) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void remove(Fqn fqn) {
		// TODO Auto-generated method stub

	}

	@Override
	public Cache<TreeNodeKey, AtomicMap<PropertyId, PropertyValue>> cache() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public GridFilesystem gfs() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public NodeWriter createLogWriter(WriteSession wsession, ReadSession rsession) throws IOException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CDDMListener cddm() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void log(String msg) {
		// TODO Auto-generated method stub

	}

	@Override
	public void modified(CacheEntryModifiedEvent<TreeNodeKey, AtomicHashMap<PropertyId, PropertyValue>> event) {
		// TODO Auto-generated method stub

	}

	@Override
	public void removed(CacheEntryRemovedEvent<TreeNodeKey, AtomicHashMap<PropertyId, PropertyValue>> event) {
		// TODO Auto-generated method stub

	}

	@Override
	public WriteSession newWriteSession(ReadSession readSession) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void reindex(WriteNode wnode, Analyzer anal, boolean includeSub) {
		// TODO Auto-generated method stub

	}

}
