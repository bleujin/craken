package net.ion.craken;

import java.io.Serializable;

public interface EntryKey extends Serializable{

	public Object get() ;
}
