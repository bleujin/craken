package net.ion.craken.db;

public interface QueryParam {
	public String getString(int i);

	public int getInt(int i);

	public String procName();


}
