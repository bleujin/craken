package net.ion.craken.listener;

public interface AsyncCDDHandler extends CDDHandler{

}
