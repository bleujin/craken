package net.ion.craken.expression;

import net.ion.craken.node.NodeCommonMap;

public interface Expression {
	public Comparable value(NodeCommonMap node) ;
}

