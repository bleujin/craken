package net.ion.craken;


public interface EntryFilter<E> {
	public boolean filter(E entry) ;
}
